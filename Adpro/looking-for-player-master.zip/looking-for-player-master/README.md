# Looking For Player

### Master status
[![Coverage](https://gitlab.cs.ui.ac.id/AdvProg/reguler-2022/student/kelas-c-blended/2006486084-Bornyto-Hamonangan/looking-for-player/looking-for-player/badges/master/pipeline.svg)](https://gitlab.cs.ui.ac.id/AdvProg/reguler-2022/student/kelas-c-blended/2006486084-Bornyto-Hamonangan/looking-for-player/looking-for-player/-/commits/master)
[![Coverage](https://gitlab.cs.ui.ac.id/AdvProg/reguler-2022/student/kelas-c-blended/2006486084-Bornyto-Hamonangan/looking-for-player/looking-for-player/badges/master/coverage.svg)](https://gitlab.cs.ui.ac.id/AdvProg/reguler-2022/student/kelas-c-blended/2006486084-Bornyto-Hamonangan/looking-for-player/looking-for-player/-/commits/master)

### Staging status
[![Coverage](https://gitlab.cs.ui.ac.id/AdvProg/reguler-2022/student/kelas-c-blended/2006486084-Bornyto-Hamonangan/looking-for-player/looking-for-player/badges/staging/pipeline.svg)](https://gitlab.cs.ui.ac.id/AdvProg/reguler-2022/student/kelas-c-blended/2006486084-Bornyto-Hamonangan/looking-for-player/looking-for-player/-/commits/staging)
[![Coverage](https://gitlab.cs.ui.ac.id/AdvProg/reguler-2022/student/kelas-c-blended/2006486084-Bornyto-Hamonangan/looking-for-player/looking-for-player/badges/staging/coverage.svg)](https://gitlab.cs.ui.ac.id/AdvProg/reguler-2022/student/kelas-c-blended/2006486084-Bornyto-Hamonangan/looking-for-player/looking-for-player/-/commits/staging)

### Dev
- Bornyto Hamonangan
- Qalbun Salim Buanaputra
- Bintang Nursyawalli Sidi
- Heidi Renata Halim
- Muhammad Hafidz Sulistyanto

### Brief description
A solution for all teams and players around the world! Get accepted by the best teams around the world and play with your great teammates! This application also supports teams to get the best talents and organize acceptance/rejection with ease. 

### Features
- Add "Looking for Player (LFP)" post
- Apply to any LFP post as player
- Get to know your application status as soon as the team accept/rejects that 
- Get notified every application updates
- 