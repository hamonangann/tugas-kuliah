package com.example.lookingforplayer.model.authentication.dto;

import lombok.Data;

@Data
public class GetUserDTO {
    long id;
    String username;
    String role;
}
