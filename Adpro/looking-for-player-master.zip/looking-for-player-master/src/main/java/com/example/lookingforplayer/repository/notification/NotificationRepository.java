package com.example.lookingforplayer.repository.notification;

import com.example.lookingforplayer.model.notification.Notification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationRepository extends JpaRepository<Notification,Integer> {
    Notification findById(int id);

}
