package com.example.lookingforplayer.repository.application;

import com.example.lookingforplayer.model.application.PlayerApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ApplicationRepository extends JpaRepository<PlayerApplication, Long> {
    @Query("SELECT a FROM PlayerApplication a WHERE a.id = ?1")
    public Optional<PlayerApplication> findById(int id);

    @Query("SELECT a FROM PlayerApplication a WHERE a.playerId = ?1")
    public List<PlayerApplication> findByPlayerId(Long id);

    @Query("SELECT a FROM PlayerApplication a WHERE a.teamId = ?1")
    public List<PlayerApplication> findByTeamId(Long id);

    @Query("SELECT a FROM PlayerApplication a WHERE a.postId = ?1")
    public List<PlayerApplication> findByPostId(String id);

    @Query("Select a From PlayerApplication a where a.teamId=?1 and a.playerId=?2 and a.isAccepted=TRUE")
    public List<PlayerApplication> findByTeamIdAndPlayerIdAAndIsAcceptedTrue(Long teamId,Long playerId);

    @Query("Select a From PlayerApplication a where a.postId=?1 and a.teamId=?2 and a.playerId=?3")
    public PlayerApplication findByPostIdAndTeamIdAndPlayerId(String postId, Long teamId,Long playerId);

    @Query("Select a From PlayerApplication a where a.postId=?1 and a.isAccepted = TRUE")
    public List<PlayerApplication> findByPostIdAndIsAcceptedTrue(String id);

    @Query("Select a From PlayerApplication a where a.postId=?1 and a.isModified = FALSE")
    public List<PlayerApplication> findByPostIdAndIsModifiedFalse(String id);
}
