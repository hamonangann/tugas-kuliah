package com.example.lookingforplayer.controller.post;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;
import com.example.lookingforplayer.service.application.ApplicationService;
import com.example.lookingforplayer.service.post.LookingForPlayerPostGetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/post")

public class LookingForPlayerPostGetController {

    private static final String REDIRECT = "redirect:/post";
    private static final String LOGIN = "redirect:login/";

    @Autowired
    private LookingForPlayerPostGetService lfpService;

    @Autowired
    private ApplicationService applicationService;

    @GetMapping(value = "/add-post")
    public String createLfpPost(Model model){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // mendapatkan data user

        if (principal instanceof CustomUserDetails) { // kalau login
            String role = ((CustomUserDetails)principal).getRole(); // mengambil role user
            if (!role.equals("TEAM")) { // larang role yang tidak berkepentingan
                return REDIRECT;
            }
            model.addAttribute("vacancyName", new LookingForPlayerPostGet());
            model.addAttribute("vacancyDesc", new LookingForPlayerPostGet());
            return "post/create_post_form";
        }
        return REDIRECT;
    }

    @PostMapping(value = "/add-post")
    public String createLfpPost(@RequestParam String vacancyName, @RequestParam String vacancyDesc){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // mendapatkan data user

        if (principal instanceof CustomUserDetails) { // kalau login
            String role = ((CustomUserDetails)principal).getRole(); // mengambil role user
            if (role.equals("TEAM")) {
                long id = ((CustomUserDetails) principal).getId();
                lfpService.create(id, vacancyName, vacancyDesc);
            }
            return REDIRECT;
        }
        return LOGIN;
    }

    @GetMapping(path = "/delete-post/{postId}")
    public String deletePost(@PathVariable(value = "postId") String postId){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // mendapatkan data user
        String idPost = postId;
        String role = ((CustomUserDetails)principal).getRole();

        // if logged in
        long userId = ((CustomUserDetails) principal).getId();
        LookingForPlayerPostGet currentPost = lfpService.getById(idPost);

        if (userId == currentPost.getTeamOwner() && role.equals("TEAM")) {
            lfpService.deletePost(postId);
        }  // unauthorized, should reject
        return REDIRECT;
    }
    @GetMapping(value = "/getpost/{postId}")
    public String getPostById(@PathVariable String postId, Model model){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // mendapatkan data user

        if (principal instanceof CustomUserDetails) { // kalau login
            String role = ((CustomUserDetails)principal).getRole(); // mengambil role user
            if (!role.equals("PLAYER")) { // larang role yang tidak berkepentingan
                return REDIRECT;
            }
        } else { // tidak login
            return LOGIN; // gunakan untuk mereject akses
        }
        var lookingForPlayerPostGet = lfpService.getById(postId);
        model.addAttribute("CurrentPost", lookingForPlayerPostGet);
        return "post/join-html";

    }

    @GetMapping()
    public String getPostAll(Model model){
        var lookingForPlayerPostGet = lfpService.getListPost();
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // mendapatkan data user
        if (principal instanceof CustomUserDetails) { // kalau login
            model.addAttribute("CurrentPost", lookingForPlayerPostGet);

        } else { // tidak login
            return LOGIN; // gunakan untuk mereject akses
        }
        return "post/list-post";
    }
    @GetMapping(value = "/updatepost/{postId}")
    public String updatePost(@PathVariable(value = "postId") String postId, Model model){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal(); // mendapatkan data user
        String idPost = postId;
        String role = ((CustomUserDetails)principal).getRole();

        // if logged in
        long userId = ((CustomUserDetails) principal).getId();
        LookingForPlayerPostGet currentPost = lfpService.getById(idPost);

        if (userId == currentPost.getTeamOwner() && role.equals("TEAM")) {
            model.addAttribute("tim", currentPost);
            model.addAttribute("TeamNameU", new LookingForPlayerPostGet());
            model.addAttribute("TeamDescU", new LookingForPlayerPostGet());
            model.addAttribute("teamId", postId);
            return "post/update_post";
        } else { // unauthorized, should reject
            return REDIRECT;
        }
    }
    @PostMapping(value = "/updatepost")
    public String updatePost(@RequestParam String teamId, @RequestParam String tName, @RequestParam String tDesc){
        lfpService.updatePost(teamId, tName, tDesc);
        return REDIRECT;
    }
}


