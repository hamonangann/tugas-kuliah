package com.example.lookingforplayer.repository.acceptedmember;

import com.example.lookingforplayer.model.acceptedmember.AcceptedMember;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AcceptedMemberRepository extends JpaRepository<AcceptedMember, Long> {

    @Query("SELECT a FROM AcceptedMember a WHERE a.teamId = ?1")
    public List<AcceptedMember> findByTeamId(Long id);
}
