package com.example.lookingforplayer.service.acceptedmember;

import com.example.lookingforplayer.model.acceptedmember.AcceptedMember;

public interface AcceptedMemberService {
    Iterable<AcceptedMember> getListAcceptedMember();
    Iterable<AcceptedMember> getListAcceptedMemberByTeam(Long teamId);
    AcceptedMember createAcceptedMember(AcceptedMember member);
}
