package com.example.lookingforplayer.service.authentication;

import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.authentication.dto.GetUserDTO;

public interface AdminService {
    Iterable<User> getListUser();
    Iterable<PlayerApplication> getListApplication();
    Iterable<GetUserDTO> getListUserDTO();

}
