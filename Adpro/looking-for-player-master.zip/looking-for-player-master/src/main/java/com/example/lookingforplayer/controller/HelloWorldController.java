package com.example.lookingforplayer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class HelloWorldController {
    @RequestMapping(method = RequestMethod.GET, path = "")
    public String index() {
        return "landing-page";
    }

    @RequestMapping(method = RequestMethod.GET, path = "/hello")
    public String helloWorld() {
        return "hello-world";
    }
}
