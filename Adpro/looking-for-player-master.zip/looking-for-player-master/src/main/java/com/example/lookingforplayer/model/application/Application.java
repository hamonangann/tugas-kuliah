package com.example.lookingforplayer.model.application;

public interface Application {
    void accepted();
    void rejected();
}
