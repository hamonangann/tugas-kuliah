package com.example.lookingforplayer.utils;

import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import org.springframework.security.core.context.SecurityContextHolder;

public class UserUtils {
    private static CustomUserDetails principal = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    public static long getLoggedInUserId(){
        return principal.getId();
    }

    public static User getLoggedInUser(){
        return principal.getUser();
    }
}
