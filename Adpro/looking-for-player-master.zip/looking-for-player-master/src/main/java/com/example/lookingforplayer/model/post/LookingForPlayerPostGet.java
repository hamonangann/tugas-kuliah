package com.example.lookingforplayer.model.post;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Table(name = "LFPtable")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity


public class LookingForPlayerPostGet {

    @Id
    @Column(name="post_id") // ini bukannya post id?
    @GeneratedValue(generator="uuid2")
    @GenericGenerator(name="uuid2", strategy= "org.hibernate.id.UUIDGenerator")
    private String id;

    @Column(name = "team_yang_buat")
    private long teamOwner; // gunakan ini sebagai foreign key ke user
    // ide: ambil data dari request authentication

    @Column(name = "post_name")
    private String name;

    @Column(name = "description")
    private String desc;

    public String getId() {
        return id;
    }


}
