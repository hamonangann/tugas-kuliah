package com.example.lookingforplayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LookingForPlayerApplication {

    public static void main(String[] args) {
        SpringApplication.run(LookingForPlayerApplication.class, args);
    }

}
