package com.example.lookingforplayer.service.post;

import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;

import java.util.List;

public interface LookingForPlayerPostGetService {
    List<LookingForPlayerPostGet> getListPost();

    LookingForPlayerPostGet create(long teamId, String name, String desc);

    LookingForPlayerPostGet getById(String id);

    void deletePost(String id);

    LookingForPlayerPostGet getByName(String name);

    LookingForPlayerPostGet updatePost(String id, String name, String desc);




}
