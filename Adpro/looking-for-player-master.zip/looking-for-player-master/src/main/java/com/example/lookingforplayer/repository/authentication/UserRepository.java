package com.example.lookingforplayer.repository.authentication;

import com.example.lookingforplayer.model.authentication.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserRepository extends JpaRepository<User, Long> {
    @Query("SELECT a FROM User a WHERE a.username = ?1")
    public User findByUsername(String username);

    @Query("SELECT a FROM User a WHERE a.id = ?1")
    public User findById(long id);
}
