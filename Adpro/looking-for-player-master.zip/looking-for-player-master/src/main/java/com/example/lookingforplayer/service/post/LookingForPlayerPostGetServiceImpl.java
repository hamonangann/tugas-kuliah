package com.example.lookingforplayer.service.post;
import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;
import com.example.lookingforplayer.repository.post.LookingForPlayerPostGetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LookingForPlayerPostGetServiceImpl implements LookingForPlayerPostGetService {
    @Autowired
    private LookingForPlayerPostGetRepository lookingForPlayerPostGetRepository;

    @Override
    public List<LookingForPlayerPostGet> getListPost() {
        return lookingForPlayerPostGetRepository.findAll();
    }

    @Override
    public LookingForPlayerPostGet create(long teamId, String name, String desc) {
        var lookingForPlayerPostGet = LookingForPlayerPostGet.builder()
                    .teamOwner(teamId)
                    .name(name)
                    .desc(desc).build();
            return lookingForPlayerPostGetRepository.save(lookingForPlayerPostGet);
    }
    @Override
    public LookingForPlayerPostGet getByName(String name){
        return lookingForPlayerPostGetRepository.findByName(name);

    }
    @Override
    public LookingForPlayerPostGet getById(String id) {
        return lookingForPlayerPostGetRepository.getById(id);
    }

    @Override
    public void deletePost(String id) {
        lookingForPlayerPostGetRepository.deleteById(id);
    }

    @Override
    public LookingForPlayerPostGet updatePost(String id, String name, String desc){
        var lfp = lookingForPlayerPostGetRepository.getById(id);
        lfp.setId(id);
        lfp.setName(name);
        lfp.setDesc(desc);
        lookingForPlayerPostGetRepository.save(lfp);
        return lfp;
    }

}
