package com.example.lookingforplayer.service.application;

import com.example.lookingforplayer.model.application.CreateApplication;
import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.repository.application.ApplicationRepository;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ApplicationService {
    @Autowired
    private ApplicationRepository applicationRepository;
    @Autowired
    private UserRepository userRepository;

    public Iterable<PlayerApplication> getListApplication(){
        return applicationRepository.findAll();
    }

    public Iterable<PlayerApplication> getApplicationByPlayerId(long playerId){
        return applicationRepository.findByPlayerId(playerId);
    }
    public Iterable<PlayerApplication> getApplicationByTeamId(long teamId){
        return applicationRepository.findByTeamId(teamId);
    }

    public Iterable<PlayerApplication> getApplicationByPostId(String postId) {
        return applicationRepository.findByPostIdAndIsModifiedFalse(postId);
    }

    public Optional<PlayerApplication> getApplicationById(int id) {
        return applicationRepository.findById(id);
    }

    public PlayerApplication apply(String description, long playerId, long teamId, String postId){
        var playerApplication=applicationRepository.findByPostIdAndTeamIdAndPlayerId(postId, teamId,playerId);
        var playerApplications=applicationRepository.findByTeamIdAndPlayerIdAAndIsAcceptedTrue(teamId,playerId);
        if(playerApplication!=null && playerApplication.getIsAccepted() ||playerApplication!=null && !playerApplication.getIsModified()){
            return null;
        }
        if(!playerApplications.isEmpty()){
            return null;
        }
        PlayerApplication application= CreateApplication.createNewApplication(playerId,teamId,postId,description);
        applicationRepository.save(application);
        return application;
    }

    public void accept(PlayerApplication application) {
        application.accepted();
        applicationRepository.save(application);
    }

    public void reject(PlayerApplication application) {
        application.rejected();
        applicationRepository.delete(application);
    }
    public Iterable<User> getAcceptedMember(String postId){
        var acceptedApps= applicationRepository.findByPostIdAndIsAcceptedTrue(postId);
        List<User> acceptedMember=new ArrayList<User>();
        if(acceptedApps!=null && !acceptedApps.isEmpty()){
            for(PlayerApplication app : acceptedApps){
                var user=userRepository.findById(app.getPlayerId());
                acceptedMember.add(user);
            }
        }
        return acceptedMember;
    }
}
