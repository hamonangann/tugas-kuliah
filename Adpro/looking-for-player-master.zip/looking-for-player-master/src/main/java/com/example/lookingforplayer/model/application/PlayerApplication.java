package com.example.lookingforplayer.model.application;

import com.example.lookingforplayer.model.authentication.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;


//player yang bikin 1 player banyak app fk player_id
//deskripsi atau permohonannya
//boolean isacepted
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name="application")
public class PlayerApplication implements Application {

    @Id
    @Column(name="application_id")
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int id;//harusnya Long biar seragam

    @Column(name="description")
    private String description;

    @Column(name="player_id")
    private long playerId;

    @Column(name="team_id")
    private long teamId;

    @Column(name="post_id")
    private String postId;

    @Column(name="is_modified") // kalau is_modified false berarti masih pending, belum di acc/reject teamnya
    private boolean isModified;

    public long getPlayerId() {return playerId;}

    public long getTeamId() {return teamId;}

    // kalau is_modified true, is_accepted true artinya diterima di tim,
    // is_accepted false artinya ditolak masuk tim
    @Column(name="is_accepted")
    private boolean isAccepted;

    @Override
    public void accepted() {
        setAccepted(true);
        setModified(true);
    }

    @Override
    public void rejected() {
        setAccepted(false);
        setModified(true);
    }

    public boolean getIsModified() {
        return isModified;
    }

    public boolean getIsAccepted() {
        return isAccepted;
    }

}
