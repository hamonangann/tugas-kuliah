package com.example.lookingforplayer.controller.authentication;

import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.dto.GetUserDTO;
import com.example.lookingforplayer.service.application.ApplicationService;
import com.example.lookingforplayer.service.authentication.AdminServiceImpl;
import com.example.lookingforplayer.utils.AuthorizationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
@RequestMapping("/admin")
public class AdminPageController {

    @Autowired
    private AdminServiceImpl adminService;

    @Autowired
    private ApplicationService applicationService;

    private static final String DENIED = "redirect:/admin/forbidden";

    @GetMapping("/forbidden")
    public String permissionDenied() { return "/admin/permission-denied"; }


    @GetMapping("")
    public String getAll(Model model) throws InterruptedException, ExecutionException {
        if (!AuthorizationUtils.isAuthorized(new ArrayList<String>(List.of("ADMIN")))) return DENIED;

        CompletableFuture<Iterable<GetUserDTO>> users = CompletableFuture.supplyAsync(() -> adminService.getListUserDTO());
        CompletableFuture<Iterable<PlayerApplication>> applications = CompletableFuture.supplyAsync(() -> adminService.getListApplication());

        CompletableFuture<Void> combined = CompletableFuture.allOf(users, applications);

        combined.get();

        users.thenAccept(u -> model.addAttribute("users", u));
        applications.thenAccept(a -> model.addAttribute("applications", a));

        return "admin/list-all";

    }

    @GetMapping("/users")
    public String getUsers(Model model) {
//        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//
//        if (principal instanceof CustomUserDetails) { // if logged in
//            String role = ((CustomUserDetails)principal).getRole();
//            if (!role.equals("ADMIN")) { // restrict unauthorized roles
//                return DENIED;
//            }
//        } else { // not logged in, should reject
//            return DENIED;
//        }
        if (!AuthorizationUtils.isAuthorized(new ArrayList<String>(List.of("ADMIN")))) return DENIED;

        var users= adminService.getListUserDTO();
        model.addAttribute("users", users);

        return "admin/list-user";
    }

    @GetMapping("/applications")
    public String getApplication(Model model) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

//        if (principal instanceof CustomUserDetails) { // if logged in
//            String role = ((CustomUserDetails)principal).getRole();
//            if (!role.equals("ADMIN")) { // restrict unauthorized roles
//                return DENIED;
//            }
//        } else { // not logged in, should reject
//            return DENIED;
//        }
        if (!AuthorizationUtils.isAuthorized(new ArrayList<String>(List.of("ADMIN")))) return DENIED;

        var applications = applicationService.getListApplication();
        model.addAttribute("applications", applications);

        return "admin/list-application";
    }


}
