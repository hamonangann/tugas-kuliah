package com.example.lookingforplayer.controller.application;

import com.example.lookingforplayer.model.acceptedmember.AcceptedMember;
import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.notification.Notification;
import com.example.lookingforplayer.service.acceptedmember.AcceptedMemberService;
import com.example.lookingforplayer.service.application.ApplicationService;
import com.example.lookingforplayer.service.authentication.CustomUserDetailsService;
import com.example.lookingforplayer.service.notification.NotificationService;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;


@Controller
public class ApplicationController {

    @Autowired
    private AcceptedMemberService acceptedMemberService;

    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private CustomUserDetailsService userService;

    private static final String REDIRECT = "redirect:/post";
    private static final String REDIRECT_HOME="redirect:/login";

    @GetMapping(path="/apply/{team_id}/{post_id}")
    public String applyGet(Model model, @PathVariable(value="team_id") long teamId, @PathVariable(value="post_id") String postId){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof CustomUserDetails) { // if logged in
            String role = ((CustomUserDetails)principal).getRole();
            if (!role.equals("PLAYER")) { // restrict unauthorized roles
                return REDIRECT;
            }
        } else { // not logged in, should reject
            return REDIRECT_HOME;
        }

        model.addAttribute("team_id",teamId);
        model.addAttribute("post_id",postId);
        return "application/apply-player";
    }

    @PostMapping(path="/apply/{team_id}/{post_id}")
    public String applyPost(
            Model model,
            @PathVariable(value="team_id") long teamId,
            @PathVariable(value="post_id") String postId,
            @RequestParam String description)
    {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof CustomUserDetails) { // if logged in
            String role = ((CustomUserDetails)principal).getRole();
            if (!role.equals("PLAYER")) { // restrict unauthorized roles
                return REDIRECT;
            }
        } else { // not logged in, should reject
            return REDIRECT_HOME;
        }

        long player_id = ((CustomUserDetails) principal).getId();
        User currentUser = ((CustomUserDetails) userService.loadUserById(player_id)).getUser();
        User teamUser = ((CustomUserDetails) userService.loadUserById(teamId)).getUser();
        var validate=applicationService.apply(description, player_id, teamId, postId);

        if(validate==null){
            return REDIRECT;
        } else{
            var playerNotification = new Notification(currentUser,teamUser.getUsername(), String.format("Your Application for team %s is being reviewed!",teamUser.getUsername()));
            var teamNotification = new Notification(teamUser,currentUser.getUsername(),"A player has send an application to your team!");
            notificationService.createNotification(playerNotification);
            notificationService.createNotification(teamNotification);
        }
        return REDIRECT;
    }

    @GetMapping(path="/application/{appl_id}")
    public String getApplication(Model model, @PathVariable(value="appl_id") String applId) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Integer applIdInt = Integer.parseInt(applId);

        if (principal instanceof CustomUserDetails) { // if logged in
            long user_id = ((CustomUserDetails) principal).getId();
            PlayerApplication currentApplication = applicationService.getApplicationById(applIdInt).get();

            if (user_id == currentApplication.getPlayerId() || user_id == currentApplication.getTeamId()) {
                model.addAttribute("appl", currentApplication);
                return "application/application";
            } else { // unauthorized, should reject
                return REDIRECT;
            }

        }
        // not logged in, should reject
        return REDIRECT_HOME;
    }

    @PostMapping(path="/application/{appl_id}/accept")
    public String acceptApplication(@PathVariable(value="appl_id") String applId) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Integer applIdInt = Integer.parseInt(applId);

        if (principal instanceof CustomUserDetails) { // if logged in
            User currentUser = ((CustomUserDetails) principal).getUser();
            long user_id = currentUser.getId();

            Optional<PlayerApplication> optionalPlayerApplication=applicationService.getApplicationById(applIdInt);
            PlayerApplication currentApplication = optionalPlayerApplication.get();

            if (user_id == currentApplication.getTeamId() && !currentApplication.getIsModified()) { // only respected team can accept/reject
                applicationService.accept(currentApplication);
                var player = ((CustomUserDetails) userService.loadUserById(currentApplication.getPlayerId())).getUser();
                var teamUser = ((CustomUserDetails) userService.loadUserById(currentApplication.getTeamId())).getUser();
                notificationService.createNotification(new Notification(player,teamUser.getUsername(),"Your application for team " + currentUser.getUsername() + "Has been accepted!"));
                acceptedMemberService.createAcceptedMember(AcceptedMember.builder()
                        .teamId(currentApplication.getTeamId())
                        .playerId(currentApplication.getPlayerId())
                        .build()
                );
                return REDIRECT;
            } else { // unauthorized, should reject
                return REDIRECT;
            }
        }
        // not logged in, should reject
        return REDIRECT_HOME;
    }

    @PostMapping(path="/application/{appl_id}/reject")
    public String rejectApplication(@PathVariable(value="appl_id") String applId) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Integer applIdInt = Integer.parseInt(applId);

        if (principal instanceof CustomUserDetails) { // if logged in
            User currentUser = ((CustomUserDetails) principal).getUser();
            long user_id = currentUser.getId();

            Optional<PlayerApplication> optionalPlayerApplication=applicationService.getApplicationById(applIdInt);
            PlayerApplication currentApplication = optionalPlayerApplication.get();

            if (user_id == currentApplication.getTeamId() && !currentApplication.getIsModified()) { // only respected team can accept/reject
                var player = ((CustomUserDetails) userService.loadUserById(currentApplication.getPlayerId())).getUser();
                var teamUser = ((CustomUserDetails) userService.loadUserById(currentApplication.getTeamId())).getUser();
                notificationService.createNotification(new Notification(player,teamUser.getUsername(),"Your application for team " + currentUser.getUsername() + "Has been rejected"));
                applicationService.reject(currentApplication);
                return REDIRECT;
            } else { // unauthorized, should reject
                return REDIRECT;
            }

        }
        // not logged in, should reject
        return REDIRECT_HOME;
    }
    @GetMapping(path="/application/get-list-application/{post_id}")
    public String listOfPostApplication(@PathVariable(value="post_id") String postId, Model model){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if(principal instanceof CustomUserDetails){
            var applications= applicationService.getApplicationByPostId(postId);
            model.addAttribute("applications", applications);
            return "application/list-post-application";
        }
        return REDIRECT_HOME;
    }
    @GetMapping(path="/application/get-accepted-member/{post_id}")
    public String ListOfAcceptedMember(@PathVariable(value="post_id") String postId,Model model){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if(principal instanceof CustomUserDetails){
            var users=applicationService.getAcceptedMember(postId);
            model.addAttribute("members",users);
            return "application/list-accepted-member";
        }
        return REDIRECT_HOME;
    }

}
