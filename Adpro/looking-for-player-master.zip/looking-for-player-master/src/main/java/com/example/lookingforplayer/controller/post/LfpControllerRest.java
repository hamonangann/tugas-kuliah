package com.example.lookingforplayer.controller.post;
import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;
import com.example.lookingforplayer.service.post.LookingForPlayerPostGetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/post")

public class LfpControllerRest {
    @Autowired
    private LookingForPlayerPostGetService lfpService;

    @GetMapping(produces = {"application/json"})
    @ResponseBody
    public ResponseEntity<List<LookingForPlayerPostGet>> getListPost() {
        return ResponseEntity.ok(lfpService.getListPost());
    }
    @GetMapping(path = "/{id}", produces = {"application/json"})
    @ResponseBody
    public ResponseEntity<?> getPost(@PathVariable(value = "id") String id) {
        var lookingForPlayerPostGet = lfpService.getById(id);
        return ResponseEntity.ok(lookingForPlayerPostGet);
    }
    @GetMapping(path = "/getbyname/{team_name}", produces = {"application/json"})
    @ResponseBody
    public ResponseEntity<?> getName(@PathVariable(value = "team_name") String name) {
        var lookingForPlayerPostGet = lfpService.getByName(name);
        return ResponseEntity.ok(lookingForPlayerPostGet);
    }
    @GetMapping(path = "/delete/{id}", produces = {"application/json"})
    public ResponseEntity<?> deletePost(@PathVariable(value = "id") String id){
        lfpService.deletePost(id);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }
}
