package com.example.lookingforplayer.service.acceptedmember;

import com.example.lookingforplayer.model.acceptedmember.AcceptedMember;
import com.example.lookingforplayer.repository.acceptedmember.AcceptedMemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AcceptedMemberServiceImpl implements AcceptedMemberService{
    @Autowired
    private AcceptedMemberRepository acceptedMemberRepository;

    @Override
    public Iterable<AcceptedMember> getListAcceptedMember() {
        return acceptedMemberRepository.findAll();
    }

    @Override
    public Iterable<AcceptedMember> getListAcceptedMemberByTeam(Long teamId) {
        return acceptedMemberRepository.findByTeamId(teamId);
    }

    @Override
    public AcceptedMember createAcceptedMember(AcceptedMember acceptedMember) {
        acceptedMemberRepository.save(acceptedMember);
        return acceptedMember;
    }


}
