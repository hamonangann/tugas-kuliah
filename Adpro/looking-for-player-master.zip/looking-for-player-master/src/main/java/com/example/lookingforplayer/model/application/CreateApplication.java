package com.example.lookingforplayer.model.application;

public class CreateApplication {
    private CreateApplication() {
        throw new IllegalStateException("Utility class");
    }
    public static PlayerApplication createNewApplication(Long playerId, Long teamId, String postId, String description){
        var playerApplication= new PlayerApplication();
        playerApplication.setPlayerId(playerId);
        playerApplication.setTeamId(teamId);
        playerApplication.setPostId(postId);
        playerApplication.setDescription(description);
        return playerApplication;
    }
}
