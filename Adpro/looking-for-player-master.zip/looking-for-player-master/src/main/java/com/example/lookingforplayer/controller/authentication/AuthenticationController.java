package com.example.lookingforplayer.controller.authentication;

import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.service.authentication.CustomUserDetailsService;
import com.example.lookingforplayer.service.notification.NotificationService;
import com.example.lookingforplayer.utils.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class AuthenticationController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/profile")
    public String viewProfile(Model model) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        long player_id = ((CustomUserDetails) principal).getId();
        model.addAttribute("notifications", notificationService.getListNotification(player_id));
        return "profile";
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "register-user";
    }

    @PostMapping("/register")
    public String processRegister(User user) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();    
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);

        if (userRepository.findByUsername(user.getUsername()) != null){ // user already existed
            return "redirect:/register?unavailable";
        };

        userRepository.save(user);
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login-user";
    }

    @GetMapping("/logout")
    public String showLogoutForm() {
        return "logout-user";
    }

    @PostMapping(path = "/validate-user",produces ={"application/json"} )
    public ResponseEntity validateUser(@RequestBody long id){
        long currentUserId = UserUtils.getLoggedInUserId();
        if(id == currentUserId){
            return ResponseEntity.ok(true);
        }
        return ResponseEntity.ok(false);
    }

}
