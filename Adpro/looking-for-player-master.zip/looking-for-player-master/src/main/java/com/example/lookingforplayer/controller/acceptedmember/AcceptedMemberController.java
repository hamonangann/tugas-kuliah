package com.example.lookingforplayer.controller.acceptedmember;

import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.service.acceptedmember.AcceptedMemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(path = "/acceptedmembers")
public class AcceptedMemberController {

    @Autowired
    private AcceptedMemberService acceptedMemberService;

    private static final String REDIRECT = "redirect:/profile";

    @GetMapping(path = "")
    public String getListAcceptedMember(Model model) {
        var listAcceptedMembers = acceptedMemberService.getListAcceptedMember();
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof CustomUserDetails) { // kalau login
            model.addAttribute("listAcceptedMembers", listAcceptedMembers);
        } else { // tidak login
            return "redirect:/login"; // gunakan untuk mereject akses
        }

        return "acceptedMember/list_accepted_member";
    }

    @GetMapping(path = "/{teamId}")
    public String getListAcceptedMemberByTeam(Model model, @PathVariable(value = "teamId") String teamId) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof CustomUserDetails) { // kalau login
            String role = ((CustomUserDetails)principal).getRole(); // mengambil role user
            if (!role.equals("PLAYER")) { // larang role yang tidak berkepentingan
                return REDIRECT;
            }
        } else { // tidak login
            return REDIRECT; // gunakan untuk mereject akses
        }

        var acceptedMembers = acceptedMemberService.getListAcceptedMemberByTeam(Long.valueOf(teamId));
        model.addAttribute("acceptedMembers", acceptedMembers);
        return "acceptedMember/detail_accepted_member";
    }
}
