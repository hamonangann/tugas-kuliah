package com.example.lookingforplayer.service.authentication;

import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.authentication.dto.GetUserDTO;
import com.example.lookingforplayer.repository.application.ApplicationRepository;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    public UserRepository userRepository;

    @Autowired
    public ApplicationRepository applicationRepository;

    @Override
    public Iterable<User> getListUser() {
        return userRepository.findAll();
    }

    @Override
    public Iterable<GetUserDTO> getListUserDTO() {
        List<User> users = userRepository.findAll();
        List<GetUserDTO> result = new ArrayList<>();
        for (User user : users) {
            GetUserDTO cur = new GetUserDTO();
            cur.setId(user.getId());
            cur.setUsername(user.getUsername());
            cur.setRole(user.getRole());
            result.add(cur);
        }
        return result;
    }

    @Override
    public Iterable<PlayerApplication> getListApplication() {
        return applicationRepository.findAll();
    }


}
