package com.example.lookingforplayer.model.notification;

import com.example.lookingforplayer.model.authentication.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(name = "id", updatable = false)
    private int id;

    @ManyToOne
    private User user;

    @Column(name ="sender")
    private String sender;

    @Column(name="message")
    protected String message;

    @Column(name="date")
    protected Date date;

    public Notification(User user,String sender,String message){
        this.user = user;
        this.sender = sender;
        this.message = message;
        this.date = new Date();
    }

    public Long getUserId(){
        return user.getId();
    }



}
