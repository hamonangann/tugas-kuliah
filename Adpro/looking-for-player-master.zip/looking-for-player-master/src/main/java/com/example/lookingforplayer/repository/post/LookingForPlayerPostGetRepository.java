package com.example.lookingforplayer.repository.post;

import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LookingForPlayerPostGetRepository extends JpaRepository<LookingForPlayerPostGet, String>{
    LookingForPlayerPostGet findByName(String name);

}
