package com.example.lookingforplayer.utils;

import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;

public class AuthorizationUtils {
    public static boolean isAuthorized(List<String> roles) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof CustomUserDetails) { // if logged in
            String role = ((CustomUserDetails)principal).getRole();
            for (String r : roles) {
                if (role.equals(r)) { // grant access
                    return true;
                }
            }
        }
        return false;
    }

//    public static boolean isRightUser(long expectedId) {
//        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//
//        if (principal instanceof CustomUserDetails) { // if logged in
//            if (((CustomUserDetails) principal).getId() == expectedId) return true;
//        }
//        return false;
//    }
}
