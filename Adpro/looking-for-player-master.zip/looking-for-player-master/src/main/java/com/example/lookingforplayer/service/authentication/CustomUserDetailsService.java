package com.example.lookingforplayer.service.authentication;

import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.authentication.dto.GetUserDTO;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    @Autowired
    private UserRepository userRepository;

    public GetUserDTO convertToGetUserDTO(User user) {
        GetUserDTO result = new GetUserDTO();
        result.setId(user.getId());
        result.setUsername(user.getUsername());
        result.setRole(user.getRole());
        return result;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new CustomUserDetails(user);

    }

    public UserDetails loadUserById(long id) throws UsernameNotFoundException {
        User user = userRepository.findById(id);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new CustomUserDetails(user);
    }
}
