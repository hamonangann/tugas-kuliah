package com.example.lookingforplayer.service.notification;

import com.example.lookingforplayer.model.notification.Notification;

public interface NotificationService {
    Notification createNotification(Notification notification);
    Notification getNotificationbyId(int id);
    void deleteNotificationbyId(int id);
    Iterable<Notification> getListNotification(long playerId);


}
