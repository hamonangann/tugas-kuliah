package com.example.lookingforplayer.controller.authentication;

import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.dto.GetUserDTO;
import com.example.lookingforplayer.service.application.ApplicationService;
import com.example.lookingforplayer.service.authentication.AdminServiceImpl;
import com.example.lookingforplayer.utils.AuthorizationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
@RequestMapping("/api/admin")
public class AdminAPIController {

    @Autowired
    private AdminServiceImpl adminService;

    @Autowired
    private ApplicationService applicationService;

    @GetMapping(path = "", produces = {"application/json"})
    @ResponseBody
    public ResponseEntity getAll() throws InterruptedException, ExecutionException {
        if (!AuthorizationUtils.isAuthorized(new ArrayList<String>(List.of("ADMIN"))))
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);

        CompletableFuture<Iterable<GetUserDTO>> users = CompletableFuture.supplyAsync(() -> adminService.getListUserDTO());
        CompletableFuture<Iterable<PlayerApplication>> applications = CompletableFuture.supplyAsync(() -> adminService.getListApplication());

        CompletableFuture<Void> combined = CompletableFuture.allOf(users, applications);

        combined.get();
        Map result = new HashMap();

        users.thenAccept(u -> result.put("users", u));
        applications.thenAccept(a -> result.put("applications", a));

        return ResponseEntity.ok(result);
    }

    @GetMapping(path = "/users", produces = {"application/json"})
    @ResponseBody
    public ResponseEntity getUsers() {
        if (!AuthorizationUtils.isAuthorized(new ArrayList<String>(List.of("ADMIN"))))
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);

        var users= adminService.getListUserDTO();
        return ResponseEntity.ok(users);
    }

    @GetMapping(path = "/applications", produces = {"application/json"})
    @ResponseBody
    public ResponseEntity getApplication() {
        if (!AuthorizationUtils.isAuthorized(new ArrayList<String>(List.of("ADMIN"))))
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);

        var applications = applicationService.getListApplication();
        return ResponseEntity.ok(applications);
    }
}
