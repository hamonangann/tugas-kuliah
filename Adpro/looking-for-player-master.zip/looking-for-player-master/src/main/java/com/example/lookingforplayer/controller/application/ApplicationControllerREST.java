package com.example.lookingforplayer.controller.application;

import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.service.application.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path="/application_rest")
public class ApplicationControllerREST {
    @Autowired
    private ApplicationService applicationService;

    @GetMapping(path="/list", produces ={"application/json"})
    @ResponseBody
    public ResponseEntity<Iterable<PlayerApplication>> getAllApplication(){
        return ResponseEntity.ok(applicationService.getListApplication());
    }
    
    @GetMapping(path="/list-post-application/{post_id}", produces ={"application/json"})
    @ResponseBody
    public ResponseEntity<Iterable<PlayerApplication>> getTeamApplication(@PathVariable(value="post_id") String postId){
        return ResponseEntity.ok(applicationService.getApplicationByPostId(postId));
    }

    @GetMapping(path="/{appl_id}")
    public ResponseEntity getApplication(@PathVariable(value="appl_id") String applId) {
       return ResponseEntity.ok(applicationService.getApplicationById(Integer.parseInt(applId)));
    }
    @GetMapping(path="/list-accepted-member/{team_id}")
    public ResponseEntity listAcceptedMember(@PathVariable(value="team_id") String teamId) {
        return ResponseEntity.ok(applicationService.getAcceptedMember(teamId));
    }
}
