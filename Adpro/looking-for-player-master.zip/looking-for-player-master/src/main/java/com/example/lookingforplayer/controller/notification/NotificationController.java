package com.example.lookingforplayer.controller.notification;

import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.notification.Notification;
import com.example.lookingforplayer.service.notification.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path="/notification")
public class NotificationController {
    @Autowired
    private NotificationService notificationService;

    @GetMapping(path = "/{id}",produces = {"application/json"})
    @ResponseBody
    public ResponseEntity<Notification> getNotification(@PathVariable(value="id") int id){
        Notification notification = notificationService.getNotificationbyId(id);
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (notification == null){
            return new ResponseEntity<Notification>(HttpStatus.NOT_FOUND);
        }

        if (principal instanceof CustomUserDetails) { // if logged in
            Long idLoggedInUser  = ((CustomUserDetails)principal).getId();
            if (idLoggedInUser != notification.getUserId()) { // restrict unauthorized roles
                return new ResponseEntity<Notification>(HttpStatus.UNAUTHORIZED);
            }
        }

        return ResponseEntity.ok(notification);
    }

    @PostMapping(produces = {"application/json"})
    @ResponseBody
    public ResponseEntity<Notification> postNotification(@RequestBody Notification notification){
        return ResponseEntity.ok(notificationService.createNotification(notification));
    }


    @DeleteMapping(path = "/{id}",produces =  "application/json")
    @ResponseBody
    public ResponseEntity<Notification> deleteNotification(@PathVariable(value = "id") int id){
        Notification notification = notificationService.getNotificationbyId(id);
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (notification == null){
            return new ResponseEntity<Notification>(HttpStatus.NOT_FOUND);
        }

        if (principal instanceof CustomUserDetails) { // if logged in
            Long idLoggedInUser  = ((CustomUserDetails)principal).getId();
            if (!(idLoggedInUser.equals(notification.getUserId()))) { // restrict unauthorized roles
                return new ResponseEntity<Notification>(HttpStatus.UNAUTHORIZED);
            }
        }
        notificationService.deleteNotificationbyId(id);
        return new ResponseEntity<Notification>(HttpStatus.OK);
    }
}
