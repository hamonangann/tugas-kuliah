package com.example.lookingforplayer.service.notification;

import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.notification.Notification;
import com.example.lookingforplayer.repository.notification.NotificationRepository;
import com.example.lookingforplayer.utils.UserUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Comparator;
import java.util.stream.Collectors;

@Service
public class NotificationServiceImpl implements NotificationService {
    @Autowired
    private NotificationRepository notificationRepository;

    @Override
    public Notification createNotification(Notification notification) {
        if (notification.getUser() == null){
            User loggedInUser = UserUtils.getLoggedInUser();
            notification.setUser(loggedInUser);
        }
        notificationRepository.save(notification);
        return notification;
    }

    @Override
    public Notification getNotificationbyId(int id) {
        return notificationRepository.findById(id);
    }

    @Override
    public void deleteNotificationbyId(int id) {
        notificationRepository.deleteById(id);
    }

    @Override
    public Iterable<Notification> getListNotification(long userId) {
        return notificationRepository.findAll().stream()
                .filter(x -> userId == (x.getUserId() != null ? x.getUserId() : -1))
                .sorted(Collections.reverseOrder(Comparator.comparingLong(x -> x.getDate().getTime())))
                .collect(Collectors.toList());
    }



}
