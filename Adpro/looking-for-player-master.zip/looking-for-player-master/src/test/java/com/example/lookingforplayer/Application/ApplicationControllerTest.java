package com.example.lookingforplayer.Application;


import com.example.lookingforplayer.controller.application.ApplicationController;
import com.example.lookingforplayer.controller.authentication.AdminPageController;
import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;
import com.example.lookingforplayer.repository.application.ApplicationRepository;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.service.acceptedmember.AcceptedMemberService;
import com.example.lookingforplayer.service.application.ApplicationService;
import com.example.lookingforplayer.service.authentication.CustomUserDetailsService;
import com.example.lookingforplayer.service.notification.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.test.context.support.TestExecutionEvent;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(controllers = ApplicationController.class)
@AutoConfigureMockMvc
public class ApplicationControllerTest {
    @Autowired
    private MockMvc mvc;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private ApplicationRepository applicationRepository;

    @MockBean
    private ApplicationService applicationService;

    @MockBean
    private NotificationService notificationService;

    @MockBean
    private CustomUserDetailsService userService;

    @MockBean
    private AcceptedMemberService acceptedMemberService;


    private User user1,user2,team1;

    private PlayerApplication app1;

    private CustomUserDetails cu1,cu2,ct1;

    private LookingForPlayerPostGet post;

    @BeforeEach
    public void setUp(){
        user1=new User();
        user1.setId(0L);
        user1.setUsername("tuna");
        user1.setPassword("Tuna_Kaleng");
        user1.setRole("PLAYER");
        cu1=new CustomUserDetails(user1);
        app1= new PlayerApplication(1,"this is a description",0L,2L,"UUI1",false,false);

        user2=new User();
        user2.setId(1L);
        user2.setUsername("Teri");
        user2.setPassword("Ikan teriiii");
        user2.setRole("PLAYER");

        team1=new User();
        team1.setId(2L);
        team1.setUsername("Beluga");
        team1.setPassword("Ikan Beluga");
        team1.setRole("TEAM");
        ct1=new CustomUserDetails(team1);

        post=new LookingForPlayerPostGet();
        post.setId("UU1I");
        post.setDesc("Looking for a mid player who has 2 years experience and can play as a middle man");
        post.setName("Looking for a mid player");
        post.setTeamOwner(team1.getId());

        when(userRepository.findByUsername("tuna")).thenReturn(user1);
        when(userRepository.findByUsername("Teri")).thenReturn(user2);
        when(userRepository.findByUsername("Beluga")).thenReturn(team1);
        when(userService.loadUserById(0L)).thenReturn(cu1);
        when(userService.loadUserById(team1.getId())).thenReturn(ct1);
    }

    @Test
    @WithUserDetails(value="tuna", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void getApplyPageTest() throws Exception{
        mvc.perform(get("/apply/2/UU1I")
                .contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }

    @Test
    @WithUserDetails(value="Beluga", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void getApplyPageTestNotPlayer() throws Exception{
        mvc.perform(get("/apply/2/UU1I")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    public void getApplyPageTestNotLogin() throws Exception{
        mvc.perform(get("/apply/2/UU1I")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    @WithUserDetails(value="tuna", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void postApplyPageTest() throws Exception{
        when(applicationService.apply("this is a description", 0L, 2L, "UU1I")).thenReturn(app1);
        mvc.perform(post("/apply/2/UU1I")
                .param("team_id","2")
                .param("post_id","UU1I")
                .param("description","this is a description")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
        );
    }

    @Test
    @WithUserDetails(value="Beluga", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void postApplyPageTestNotPlayer() throws Exception{
         mvc.perform(post("/apply/2/UU1I")
                        .param("team_id","2")
                        .param("post_id","UU1I")
                        .param("description","this is a description")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    public void postApplyPageTestNotLogin() throws Exception{
        mvc.perform(post("/apply/2/UU1I")
                        .param("team_id","2")
                        .param("post_id","UU1I")
                        .param("description","this is a description")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    @WithUserDetails(value="tuna", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void getApplicationById() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(get("/application/1")
                .contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML)
                );
    }

    @Test
    @WithUserDetails(value="Teri", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void getApplicationByIdNotRightUser() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(get("/application/1")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    public void getApplicationByIdNotLogin() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(get("/application/1")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    @WithUserDetails(value="Beluga", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void applyAppAcceptTest() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(post("/application/1/accept")
                        .param("appl_id","1")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    @WithUserDetails(value="Teri", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void applyAppAcceptTestNotRightUser() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(post("/application/1/accept")
                        .param("appl_id","1")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    public void applyAppAcceptTestNotLogin() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(post("/application/1/accept")
                        .param("appl_id","1")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    @WithUserDetails(value="Beluga",userDetailsServiceBeanName ="userDetailsService",setupBefore=TestExecutionEvent.TEST_EXECUTION)
    public void applyAppRejectTest() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(post("/application/1/reject")
                .param("appl_id","1")
                .with(csrf())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
        );
    }

    @Test
    @WithUserDetails(value="tuna",userDetailsServiceBeanName ="userDetailsService",setupBefore=TestExecutionEvent.TEST_EXECUTION)
    public void applyAppRejectTestNotRightUser() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(post("/application/1/reject")
                        .param("appl_id","1")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    public void applyAppRejectTestNotLogin() throws Exception{
        when(applicationService.getApplicationById(1)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(post("/application/1/reject")
                        .param("appl_id","1")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection()
                );
    }


    @Test
    @WithUserDetails(value="Beluga",userDetailsServiceBeanName="userDetailsService",setupBefore=TestExecutionEvent.TEST_EXECUTION)
    public void getApplicationsByPostId() throws Exception{
        Iterable<PlayerApplication> playerApplications= Arrays.asList(app1);
        when(applicationService.getApplicationByPostId("UUI1")).thenReturn(playerApplications);
        when(applicationRepository.findByPostIdAndIsModifiedFalse("UUI1")).thenReturn((List<PlayerApplication>) playerApplications);
        mvc.perform(get("/application/get-list-application/UUI1")
                .param("post_id","UUI1")
                .contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML)
        );
    }

    @Test
    public void getApplicationsByPostIdNotLogin() throws Exception{
        mvc.perform(get("/application/get-list-application/UUI1")
                        .param("post_id","UUI1")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().is3xxRedirection()
                );
    }

    @Test
    @WithUserDetails(value="Beluga",userDetailsServiceBeanName="userDetailsService",setupBefore=TestExecutionEvent.TEST_EXECUTION)
    public void getAcceptedMemberByPostId() throws Exception{
        Iterable<User> players = Arrays.asList(user1);
        when(applicationService.getAcceptedMember("UUI1")).thenReturn(players);
        mvc.perform(get("/application/get-accepted-member/UUI1")
                        .param("post_id","UUI1")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML)
                );
    }

    @Test
    public void getAcceptedMemberByPostIdNotLogin() throws Exception{
        mvc.perform(get("/application/get-accepted-member/UUI1")
                        .param("post_id","UUI1")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().is3xxRedirection()
                );
    }
}
