package com.example.lookingforplayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LookingForPlayerApplicationTests {

    @Test
    void contextLoads() {
    }

}
