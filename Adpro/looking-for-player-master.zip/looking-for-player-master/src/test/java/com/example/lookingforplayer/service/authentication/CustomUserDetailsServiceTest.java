package com.example.lookingforplayer.service.authentication;

import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.authentication.dto.GetUserDTO;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.annotation.Rollback;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.hamcrest.Matchers.hasProperty;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@SpringBootTest
public class CustomUserDetailsServiceTest {
    @InjectMocks
    private CustomUserDetailsService userService;

    @Mock
    private UserRepository userRepository;

    private User user;
    private CustomUserDetails userDetail;

    @BeforeEach // sebelum ngejalanin semua test
    public void setUp() { // buat user dulu
        user = new User();
        user.setId(0L);
        user.setUsername("audi");
        user.setPassword("bUDI");
        user.setRole("ADMIN");

        userDetail = new CustomUserDetails(user);
    }

    @Test
    public void testConvertToGetUserDTO() {
        GetUserDTO loaded = userService.convertToGetUserDTO(user);
        assertEquals(user.getId(), loaded.getId());
        assertEquals(user.getUsername(), loaded.getUsername());
        assertEquals(user.getRole(), loaded.getRole());
    }

    @Test
    public void testLoadUserByUsernameExist() {
        when(userRepository.findByUsername("audi")).thenReturn(user);
        CustomUserDetails loaded = (CustomUserDetails) userService.loadUserByUsername(user.getUsername());
        assertEquals(loaded.getId(), userDetail.getId());
        assertEquals(loaded.getUsername(), userDetail.getUsername());
    }

    @Test
    public void testLoadUserByUsernameNotExist() {
        when(userRepository.findByUsername("Paijo")).thenReturn(null);
        Exception e = assertThrows(UsernameNotFoundException.class, () -> {
            userService.loadUserByUsername("Paijo");
        });
        assertTrue(e.getMessage().contains("User not found"));
    }

    @Test
    public void testLoadUserByIdExist() {
        when(userRepository.findById(0L)).thenReturn(user);
        CustomUserDetails loaded = (CustomUserDetails) userService.loadUserById(user.getId());
        assertEquals(loaded.getId(), userDetail.getId());
        assertEquals(loaded.getUsername(), userDetail.getUsername());
    }

    @Test
    public void testLoadUserByIdNotExist() {
        when(userRepository.findById(99L)).thenReturn(null);
        Exception e = assertThrows(UsernameNotFoundException.class, () -> {
            userService.loadUserById(99L);
        });
        assertTrue(e.getMessage().contains("User not found"));

    }

}
