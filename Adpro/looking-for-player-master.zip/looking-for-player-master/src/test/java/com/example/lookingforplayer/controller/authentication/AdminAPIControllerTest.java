package com.example.lookingforplayer.controller.authentication;

import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.service.application.ApplicationService;
import com.example.lookingforplayer.service.authentication.AdminServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.TestExecutionEvent;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(controllers = AdminAPIController.class)
@AutoConfigureMockMvc
public class AdminAPIControllerTest {
    @Autowired
    private MockMvc mvc;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private AdminServiceImpl adminServiceImpl;

    @MockBean
    private ApplicationService applicationService;

    private User user1, user2;
    private CustomUserDetails userDetails1, userDetails2;

    @BeforeEach // sebelum ngejalanin semua test
    public void setUp() { // buat user dulu
        user1 = new User();
        user1.setId(0L);
        user1.setUsername("audi");
        user1.setPassword("bUDI");
        user1.setRole("ADMIN");

        user2 = new User();
        user2.setId(1L);
        user2.setUsername("bono");
        user2.setPassword("bOnI");
        user2.setRole("PLAYER");

        userDetails1 = new CustomUserDetails(user1);
        userDetails2 = new CustomUserDetails(user2);
        when(userRepository.findByUsername("audi")).thenReturn(user1);
        when(userRepository.findByUsername("bono")).thenReturn(user2);

    }

    @Test
    @WithUserDetails(value = "audi", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void testGetMainPage() throws Exception {
        when(adminServiceImpl.getListUser()).thenReturn(Collections.emptyList());
        when(applicationService.getListApplication()).thenReturn(Collections.emptyList());
        mvc.perform(get("/api/admin")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }


    @Test
    @WithUserDetails(value = "bono", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void testGetMainPageNotAdmin() throws Exception {
        mvc.perform(get("/api/admin")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithUserDetails(value = "audi", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void testGetUsersPage() throws Exception {
        when(adminServiceImpl.getListUser()).thenReturn(Collections.emptyList());
        mvc.perform(get("/api/admin/users")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }

    @Test
    @WithUserDetails(value = "bono", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void testGetUsersPageNotAdmin() throws Exception {
        mvc.perform(get("/api/admin/users")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithUserDetails(value = "audi", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void testGetApplicationsPage() throws Exception {
        when(applicationService.getListApplication()).thenReturn(Collections.emptyList());
        mvc.perform(get("/api/admin/applications")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }

    @Test
    @WithUserDetails(value = "bono", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void testGetApplicationsPageNotAdmin() throws Exception {
        mvc.perform(get("/api/admin/applications")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden());
    }
}
