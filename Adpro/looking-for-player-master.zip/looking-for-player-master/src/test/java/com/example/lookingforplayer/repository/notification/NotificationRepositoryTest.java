package com.example.lookingforplayer.repository.notification;

import com.example.lookingforplayer.model.notification.Notification;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;
import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
class NotificationRepositoryTest {
    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private NotificationRepository notificationRepository;

    @Test
    void testCreateNotification(){
        Notification notification = new Notification();
        Notification savedNotification = notificationRepository.save(notification);
        Notification existNotificationn = entityManager.find(Notification.class,notification.getId());
        assertEquals(savedNotification,existNotificationn);

    }

}
