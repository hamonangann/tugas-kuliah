package com.example.lookingforplayer.service.acceptedmember;

import com.example.lookingforplayer.model.acceptedmember.AcceptedMember;
import com.example.lookingforplayer.repository.acceptedmember.AcceptedMemberRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AcceptedMemberServiceImplTest {

    @Mock
    private AcceptedMemberRepository acceptedMemberRepository;

    @InjectMocks
    private AcceptedMemberServiceImpl acceptedMemberService;

    private AcceptedMember acceptedMember1, acceptedMember2, acceptedMember3;

    @BeforeEach
    public void setup() {
        acceptedMember1 = AcceptedMember.builder()
                .memberId(1L)
                .teamId(1L)
                .playerId(3L)
                .joinedDate(new Date())
                .build();

        acceptedMember2 = AcceptedMember.builder()
                .memberId(2L)
                .teamId(1L)
                .playerId(4L)
                .joinedDate(new Date())
                .build();

        acceptedMember3 = AcceptedMember.builder()
                .memberId(3L)
                .teamId(2L)
                .playerId(5L)
                .joinedDate(new Date())
                .build();
    }

    @Test
    public void whenGetListAcceptedMemberShouldReturnAllTeamMember() throws Exception {
        Iterable<AcceptedMember> acceptedMembers = Arrays.asList(acceptedMember1, acceptedMember2, acceptedMember3);
        when(acceptedMemberRepository.findAll()).thenReturn((List<AcceptedMember>) acceptedMembers);
        Iterable<AcceptedMember> acceptedMembersResult = acceptedMemberService.getListAcceptedMember();
        assertIterableEquals(acceptedMembers, acceptedMembersResult);
    }

    @Test
    public void whenGetListAcceptedMemberByTeamShouldReturnOnlyTheirTeamMember() throws Exception {
        Iterable<AcceptedMember> acceptedMembers = Arrays.asList(acceptedMember1, acceptedMember2);
        when(acceptedMemberRepository.findByTeamId(1L)).thenReturn((List<AcceptedMember>) acceptedMembers);
        Iterable<AcceptedMember> acceptedMemberResult = acceptedMemberService.getListAcceptedMemberByTeam(1L);
        assertIterableEquals(acceptedMembers, acceptedMemberResult);
    }

    @Test
    public void whenGetListAcceptedMemberByTeamDoesNotExistShouldThrowException() {
        when(acceptedMemberRepository.findByTeamId(6L)).thenThrow(new NoSuchElementException());
        assertThrows(NoSuchElementException.class,
                () -> acceptedMemberRepository.findByTeamId(6L));
    }

}
