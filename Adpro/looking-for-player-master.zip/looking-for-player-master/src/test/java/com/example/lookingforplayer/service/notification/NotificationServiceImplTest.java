package com.example.lookingforplayer.service.notification;

import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.notification.Notification;
import com.example.lookingforplayer.repository.application.ApplicationRepository;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.repository.notification.NotificationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.TestExecutionEvent;
import org.springframework.security.test.context.support.WithUserDetails;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.when;

@SpringBootTest
class NotificationServiceImplTest {
    @InjectMocks
    private NotificationServiceImpl notificationService;

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private ApplicationRepository applicationRepository;

    @MockBean
    private UserRepository userRepository;

    private User user1, user2;
    private PlayerApplication app1, app2;
    private Notification expectedPlayerNotification, expectedTeamNotification;
    private CustomUserDetails userDetails1,userDetails2;



    @BeforeEach
    public void setUp() throws Exception {
        user1 = new User();
        user1.setId(0L);
        user1.setUsername("audi");
        user1.setPassword("bUDI");
        user1.setRole("TEAM");

        user2 = new User();
        user2.setId(1L);
        user2.setUsername("bono");
        user2.setPassword("bOnI");
        user2.setRole("PLAYER");

        userDetails1 = new CustomUserDetails(user1);
        userDetails2 = new CustomUserDetails(user2);
        when(userRepository.findByUsername("audi")).thenReturn(user1);
        when(userRepository.findByUsername("bono")).thenReturn(user2);


        expectedPlayerNotification = new Notification(
                0,user2,user1.getUsername(),
                String.format("Your application for team %s is being reviewed", user1.getUsername()),
                new Date()
                );
        expectedTeamNotification = new Notification(
                1,user1,user2.getUsername(),
                "A player has submitted an application to your team",
                new Date()
        );
    }

    @Test
    @WithUserDetails(value = "bono", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    void testNotificationCreatedSuccessfully(){
        Notification initialPlayerNotification = new Notification(user2,user1.getUsername(),String.format("Your application for team %s is being reviewed", user1.getUsername()));
        Notification testPlayerNotification = notificationService.createNotification(initialPlayerNotification);

        assertEquals(testPlayerNotification.getId() , expectedPlayerNotification.getId());
        assertEquals(testPlayerNotification.getUser(),expectedPlayerNotification.getUser());
        assertEquals(testPlayerNotification.getSender(),expectedPlayerNotification.getSender());
    }

    @Test
    void testGetListNotification(){
        Iterable<Notification> notifications = Arrays.asList(expectedPlayerNotification, expectedTeamNotification);
        Iterable<Notification> expectedListNotifications = Arrays.asList(expectedTeamNotification);
        when(notificationRepository.findAll()).thenReturn((List<Notification>) notifications);
        Iterable<Notification> loaded = notificationService.getListNotification(0);
        assertIterableEquals(loaded, expectedListNotifications);
    }

    @Test
    @WithUserDetails(value = "bono", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    void testDeleteNotification(){
        Notification initialPlayerNotification = new Notification(user2,user1.getUsername(),String.format("Your application for team %s is being reviewed", user1.getUsername()));
        notificationService.createNotification(initialPlayerNotification);
        notificationService.deleteNotificationbyId(initialPlayerNotification.getId());
        assertNull(notificationService.getNotificationbyId(initialPlayerNotification.getId()));
    }

    @Test
    @WithUserDetails(value = "bono", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    void testGetNotification(){
        Notification initialPlayerNotification = new Notification(user2,user1.getUsername(),String.format("Your application for team %s is being reviewed", user1.getUsername()));
        when(notificationRepository.findById(initialPlayerNotification.getId())).thenReturn(initialPlayerNotification);
        notificationService.createNotification(initialPlayerNotification);
        assertEquals(initialPlayerNotification,notificationService.getNotificationbyId(initialPlayerNotification.getId()));
    }
}
