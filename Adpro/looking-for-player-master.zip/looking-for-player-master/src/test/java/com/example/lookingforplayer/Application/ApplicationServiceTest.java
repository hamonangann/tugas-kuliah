package com.example.lookingforplayer.Application;

import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.repository.application.ApplicationRepository;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.service.application.ApplicationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@SpringBootTest
public class ApplicationServiceTest {
    @InjectMocks
    private ApplicationService applicationService;

    @Mock
    private ApplicationRepository applicationRepository;

    @Mock
    private User user1, user2, user3, team1;
    private PlayerApplication app1, app2,app3;

    @Mock
    private UserRepository userRepository;

    @BeforeEach // sebelum ngejalanin semua test
    public void setUp() { // buat user dulu
        user1 = new User();
        user1.setId(0L);
        user1.setUsername("Mobile Legend");
        user1.setPassword("MlBbbb");
        user1.setRole("TEAM");

        team1 = new User();
        team1.setId(3L);
        team1.setUsername("Champion Legue");
        team1.setPassword("Cl0lo");
        team1.setRole("TEAM");

        user2 = new User();
        user2.setId(1L);
        user2.setUsername("bona");
        user2.setPassword("bOn4");
        user2.setRole("PLAYER");

        user3 = new User();
        user3.setId(2L);
        user3.setUsername("bono");
        user3.setPassword("bOnI");
        user3.setRole("PLAYER");

        app1 = new PlayerApplication();
        app1.setId(0);
        app1.setPlayerId(user2.getId());
        app1.setTeamId(user1.getId());
        app1.setPostId("UI12");
        app1.setModified(false);

        app2 = new PlayerApplication();
        app2.setId(1);
        app2.setPlayerId(user3.getId());
        app2.setTeamId(user1.getId());
        app2.setPostId("UI12");
        app2.setModified(false);

        app3=new PlayerApplication();
        app3.setId(2);
        app3.setPlayerId(user2.getId());
        app3.setTeamId(team1.getId());
        app3.setModified(false);

    }

    @Test
    public void getAllApplicationTest(){
        Iterable<PlayerApplication> applications = Arrays.asList(app1, app2);
        when(applicationRepository.findAll()).thenReturn((List<PlayerApplication>) applications);
        Iterable<PlayerApplication> playerApplications = applicationService.getListApplication();
        assertIterableEquals(applications, playerApplications);
    }

    @Test
    public void getApplicationByIdTest(){
        when(applicationRepository.findById(0)).thenReturn(Optional.ofNullable(app1));
        Optional<PlayerApplication> playerApplication = applicationService.getApplicationById(0);
        assertEquals(playerApplication.get().getId(), app1.getId());
        assertEquals(playerApplication.get().getDescription(), app1.getDescription());
        assertEquals(playerApplication.get().getIsAccepted(), app1.getIsAccepted());
        assertEquals(playerApplication.get().getIsModified(), app1.getIsModified());

    }

    @Test
    public void getApplicationByPlayerIdTest(){
        Iterable<PlayerApplication> applications = Arrays.asList(app1, app3);
        when(applicationRepository.findByPlayerId(user2.getId())).thenReturn((List<PlayerApplication>) applications);
        Iterable<PlayerApplication> playerApplications = applicationService.getApplicationByPlayerId(user2.getId());
        assertIterableEquals(applications, playerApplications);
    }
    @Test
    public void getApplicationByTeamIdTest(){
        Iterable<PlayerApplication> applications=Arrays.asList(app1,app2);
        when(applicationRepository.findByTeamId(user1.getId())).thenReturn((List< PlayerApplication>)applications);
        Iterable<PlayerApplication> playerApplications=applicationService.getApplicationByTeamId(user1.getId());
        assertIterableEquals(applications,playerApplications);
    }
    @Test
    public void getApplicationByPostIdTest(){
        Iterable<PlayerApplication> applications=Arrays.asList(app1,app2);
        when(applicationRepository.findByPostIdAndIsModifiedFalse("UI12")).thenReturn((List<PlayerApplication>)applications);
        Iterable<PlayerApplication> playerApplications=applicationService.getApplicationByPostId("UI12");
        assertIterableEquals(applications,playerApplications);
    }
    @Test
    public void rejectApplicationTest(){
        applicationService.reject(app1);
        assertEquals(false,app1.getIsAccepted());
    }
    @Test
    public void acceptApplicationTest(){
        applicationService.accept(app1);
        assertEquals(true,app1.getIsAccepted());
    }

    @Test
    public void getAcceptedMemberTest(){
        List<PlayerApplication> dummyReturn = Arrays.asList(app1);
        when(applicationRepository.findByPostIdAndIsAcceptedTrue("someId")).thenReturn(dummyReturn);
        when(userRepository.findById(0L)).thenReturn(user1);
        when(userRepository.findById(1L)).thenReturn(user2);
        when(userRepository.findById(2L)).thenReturn(user3);
        when(userRepository.findById(3L)).thenReturn(team1);
        Iterable<User> loaded = applicationService.getAcceptedMember("someId");
        Iterator it = loaded.iterator();
        int dummyReturnIndex = 0;
        while (it.hasNext()) {
            User current = (User) it.next();
            assertEquals(current.getId(), dummyReturn.get(dummyReturnIndex).getPlayerId());
        }
    }

    @Test
    public void applyTestApplicationAlreadyAccepted() {
        app1.setAccepted(true);
        when(applicationRepository.findByPostIdAndTeamIdAndPlayerId("postId", 3L, 0L)).thenReturn(app1);
        when(applicationRepository.findByTeamIdAndPlayerIdAAndIsAcceptedTrue(3L, 0L)).thenReturn(Collections.emptyList());
        assertEquals(applicationService.apply("some desc", 0L, 3L, "postId"), null);
        app1.setAccepted(false);
    }

    @Test
    public void applyTestAlreadyAcceptedByTeam() {
        when(applicationRepository.findByPostIdAndTeamIdAndPlayerId("postId", 3L, 0L)).thenReturn(null);
        when(applicationRepository.findByTeamIdAndPlayerIdAAndIsAcceptedTrue(3L, 0L)).thenReturn(Arrays.asList(app1));
        assertEquals(applicationService.apply("some desc", 0L, 3L, "postId"), null);
    }

    @Test
    public void applyTestSuccessApplication() {
        when(applicationRepository.findByPostIdAndTeamIdAndPlayerId("postId", 3L, 0L)).thenReturn(null);
        when(applicationRepository.findByTeamIdAndPlayerIdAAndIsAcceptedTrue(3L, 0L)).thenReturn(Collections.emptyList());
        PlayerApplication loaded = applicationService.apply("some desc", 0L, 3L, "postId");
        assertEquals(loaded.getPlayerId(), 0L);
        assertEquals(loaded.getTeamId(), 3L);
        assertEquals(loaded.getPostId(), "postId");
        assertEquals(loaded.getDescription(), "some desc");
    }
}































































