package com.example.lookingforplayer.controller.acceptedMember;

import com.example.lookingforplayer.controller.acceptedmember.AcceptedMemberController;
import com.example.lookingforplayer.model.acceptedmember.AcceptedMember;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.service.acceptedmember.AcceptedMemberService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.TestExecutionEvent;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc
@WebMvcTest(controllers = AcceptedMemberController.class)
public class AcceptedMemberControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private AcceptedMemberService acceptedMemberService;


    private User user1, user2, user3;
    private CustomUserDetails userDetails1, userDetails2;
    private LookingForPlayerPostGet post;
    private AcceptedMember acceptedMember1, acceptedMember2;

    @BeforeEach
    public void setUp() {
        user1 = new User();
        user1.setId(0L);
        user1.setUsername("teamdemo");
        user1.setPassword("1234567890");
        user1.setRole("TEAM");

        user2 = new User();
        user2.setId(1L);
        user2.setUsername("playerdemo");
        user2.setPassword("1234567890");
        user2.setRole("PLAYER");

        user3 = new User();
        user3.setId(2L);
        user3.setUsername("player2demo");
        user3.setPassword("1234567890");
        user3.setRole("PLAYER");

        userDetails1 = new CustomUserDetails(user1);
        userDetails2 = new CustomUserDetails(user2);

        when(userRepository.findByUsername("teamdemo")).thenReturn(user1);
        when(userRepository.findByUsername("playerdemo")).thenReturn(user2);
        when(userRepository.findByUsername("player2demo")).thenReturn(user3);

        post = new LookingForPlayerPostGet();
        post.setId("UID1");
        post.setName("Need Dota Mid!");
        post.setTeamOwner(user1.getId());
        post.setDesc("Looking for dota 2 player for mid position");

        acceptedMember1 = AcceptedMember.builder()
                .memberId(1L)
                .teamId(user1.getId())
                .playerId(user2.getId())
                .joinedDate(new Date())
                .build();

        acceptedMember2 = AcceptedMember.builder()
                .memberId(2L)
                .teamId(user1.getId())
                .playerId(user3.getId())
                .joinedDate(new Date())
                .build();

    }

    @Test
    @WithUserDetails(
            value="playerdemo",
            userDetailsServiceBeanName = "userDetailsService",
            setupBefore = TestExecutionEvent.TEST_EXECUTION
    )
    public void testGetListAcceptedMembersShouldReturnSuccess() throws Exception {
        List<AcceptedMember> acceptedMemberList = Arrays.asList(acceptedMember1, acceptedMember2);
        when(acceptedMemberService.getListAcceptedMember()).thenReturn(acceptedMemberList);
        mvc.perform(get("/acceptedmembers").contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }

    @Test
    public void testGetListAcceptedMembersIfNotLoginShouldRedirect() throws Exception {
        List<AcceptedMember> acceptedMemberList = Arrays.asList(acceptedMember1, acceptedMember2);
        when(acceptedMemberService.getListAcceptedMember()).thenReturn(acceptedMemberList);
        mvc.perform(get("/acceptedmembers").contentType(MediaType.TEXT_HTML))
                .andExpect(status().is3xxRedirection());
    }
}
