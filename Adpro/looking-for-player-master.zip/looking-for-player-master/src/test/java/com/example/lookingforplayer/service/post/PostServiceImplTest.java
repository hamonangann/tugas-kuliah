package com.example.lookingforplayer.service.post;
import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;
import com.example.lookingforplayer.repository.post.LookingForPlayerPostGetRepository;
import com.example.lookingforplayer.service.post.LookingForPlayerPostGetService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.annotation.Rollback;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class PostServiceImplTest {
    @InjectMocks
    private LookingForPlayerPostGetServiceImpl lfpService;

    @Mock
    private LookingForPlayerPostGetRepository lookingForPlayerPostGetRepository;


    private LookingForPlayerPostGet lookingForPlayerPostGet;

    private LookingForPlayerPostGet lookingForPlayerPostGet2;

    private LookingForPlayerPostGet temp;


    @BeforeEach
    void SetUp(){
        lookingForPlayerPostGet = new LookingForPlayerPostGet();
        lookingForPlayerPostGet.setId("P1");
        lookingForPlayerPostGet.setName("Test1");
        lookingForPlayerPostGet.setTeamOwner(1);
        lookingForPlayerPostGet.setDesc("Mencari Player");

        lookingForPlayerPostGet2 = new LookingForPlayerPostGet();
        lookingForPlayerPostGet2.setId("P2");
        lookingForPlayerPostGet.setName("Test2");
        lookingForPlayerPostGet.setDesc("Mencari Player 2");

        temp = new LookingForPlayerPostGet();
        temp.setId("P3");
        temp.setName("Test3");
        temp.setTeamOwner(1);
        temp.setDesc("Mencari Player 3");

    }
    @Test
    void GetListTest(){
        Iterable<LookingForPlayerPostGet> post = Arrays.asList(lookingForPlayerPostGet, lookingForPlayerPostGet2);
        when(lookingForPlayerPostGetRepository.findAll()).thenReturn((List<LookingForPlayerPostGet>) post);
        Iterable<LookingForPlayerPostGet> loaded = lfpService.getListPost();
        assertIterableEquals(loaded, post);
    }

    @Test
    void CreateTest(){
        lfpService.create(1, "TestTeam1", "TestTeamDesc");

    }
    @Test
    void GetByIdTest(){
        when(lookingForPlayerPostGetRepository.getById("P1")).thenReturn(lookingForPlayerPostGet);
        LookingForPlayerPostGet post = lfpService.getById("P1");
        assertEquals(post.getId(), lookingForPlayerPostGet.getId());
        assertEquals(post.getName(), lookingForPlayerPostGet.getName());
        assertEquals(post.getDesc(), lookingForPlayerPostGet.getDesc());
        assertEquals(post.getTeamOwner(), lookingForPlayerPostGet.getTeamOwner());
    }

    @Test
    void GetByNameTest(){
        when(lookingForPlayerPostGetRepository.findByName("Test1")).thenReturn(lookingForPlayerPostGet);
        LookingForPlayerPostGet post = lfpService.getByName("Test1");
        assertEquals(post.getId(), lookingForPlayerPostGet.getId());
        assertEquals(post.getName(), lookingForPlayerPostGet.getName());
        assertEquals(post.getDesc(), lookingForPlayerPostGet.getDesc());
        assertEquals(post.getTeamOwner(), lookingForPlayerPostGet.getTeamOwner());
    }

    @Test
    void DeleteTest(){
        ArrayList<LookingForPlayerPostGet> post = new ArrayList<>(Arrays.asList(lookingForPlayerPostGet, lookingForPlayerPostGet2));
        when(lookingForPlayerPostGetRepository.getById("P1")).thenReturn(lookingForPlayerPostGet);
        LookingForPlayerPostGet temp = lookingForPlayerPostGet;
        lfpService.deletePost("P1");
        assertEquals(temp, lookingForPlayerPostGet);
    }
    @Test
    void UpdatePostTest(){
        when(lookingForPlayerPostGetRepository.getById("P3")).thenReturn(temp);

        assertEquals("Test3", temp.getName());
        assertEquals("Mencari Player 3", temp.getDesc());

        lfpService.updatePost("P3","Testupdated", "Mencari Player Updated");

        assertNotEquals("Test3", temp.getName());
        assertNotEquals("Mencari Player 3", temp.getDesc());
    }
    @AfterEach
    void reset() { // hapus post dummy
        lookingForPlayerPostGetRepository.delete(lookingForPlayerPostGet);
        lookingForPlayerPostGetRepository.delete(lookingForPlayerPostGet2);
        lookingForPlayerPostGetRepository.delete(temp);
    }
}