package com.example.lookingforplayer.controller.authentication;

import com.example.lookingforplayer.model.application.Application;
import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.authentication.dto.GetUserDTO;
import com.example.lookingforplayer.repository.application.ApplicationRepository;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.service.authentication.AdminServiceImpl;
import com.example.lookingforplayer.service.authentication.CustomUserDetailsService;
import com.example.lookingforplayer.service.notification.NotificationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.test.context.support.TestExecutionEvent;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(controllers = AuthenticationController.class)
@AutoConfigureMockMvc
public class AuthenticationControllerTest {
    @Autowired
    private MockMvc mvc;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @MockBean
    private NotificationService notificationService;

    private User user1, user2;
    private CustomUserDetails userDetails1, userDetails2;

    @BeforeEach // sebelum ngejalanin semua test
    public void setUp() { // buat user dulu
        user1 = new User();
        user1.setId(0L);
        user1.setUsername("audi");
        user1.setPassword("bUDI");
        user1.setRole("ADMIN");

        user2 = new User();
        user2.setId(1L);
        user2.setUsername("bono");
        user2.setPassword("bOnI");
        user2.setRole("PLAYER");

        userDetails1 = new CustomUserDetails(user1);
        userDetails2 = new CustomUserDetails(user2);
        when(userRepository.findByUsername("audi")).thenReturn(user1);
        when(userRepository.findByUsername("bono")).thenReturn(user2);

    }

    // Helper method
    private String mapToJson(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
    }


    @Test
    @WithUserDetails(value = "audi", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void testViewProfile() throws Exception {
        mvc.perform(get("/profile")
                .contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }

    @Test
    public void testGetRegister() throws Exception {
        mvc.perform(get("/register")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }

    @Test
    public void testPostRegisterSuccess() throws Exception {
        when(userRepository.findByUsername("audi")).thenReturn(null);
        when(notificationService.getListNotification(0L)).thenReturn(Collections.emptyList());
        mvc.perform(post("/register")
                        .param("username", "audi")
                        .param("role", "PLAYER")
                        .param("password", "bUDI")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    public void testPostRegisterUnavailable() throws Exception {
        when(userRepository.findByUsername("audi")).thenReturn(user1);
        when(notificationService.getListNotification(0L)).thenReturn(Collections.emptyList());
        mvc.perform(post("/register")
                        .param("username", "audi")
                        .param("role", "PLAYER")
                        .param("password", "bUDI")
                        .with(csrf())
                        .contentType(MediaType.TEXT_HTML)
                        .content(mapToJson(user1)))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    public void testGetLogin() throws Exception {
        mvc.perform(get("/login")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }

    @Test
    @WithUserDetails(value = "bono", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    public void testGetLogout() throws Exception {
        mvc.perform(get("/logout")
                        .contentType(MediaType.TEXT_HTML))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }


//    @Test
//    public void testGetListUserDTO() {
//        Iterable<User> users = Arrays.asList(user1, user2);
//        when(userRepository.findAll()).thenReturn((List<User>) users);
//        Iterable<GetUserDTO> loaded = adminService.getListUserDTO();
//        Iterator<GetUserDTO> it = loaded.iterator();
//        Iterator<User> it2 = users.iterator();
//        while (it.hasNext()) {
//            GetUserDTO dto = it.next();
//            User actual = it2.next();
//            assertEquals(dto.getId(), actual.getId());
//            assertEquals(dto.getRole(), actual.getRole());
//            assertEquals(dto.getId(), actual.getId());
//        }
//
//    }
//
//    @Test
//    public void testGetListApplications() {
//        Iterable<PlayerApplication> applications = Arrays.asList(app1, app2);
//        when(applicationRepository.findAll()).thenReturn((List<PlayerApplication>) applications);
//        Iterable<PlayerApplication> loaded = adminService.getListApplication();
//        assertIterableEquals(loaded, applications);
//    }

}

