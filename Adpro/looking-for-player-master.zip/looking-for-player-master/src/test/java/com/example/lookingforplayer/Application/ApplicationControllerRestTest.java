package com.example.lookingforplayer.Application;


import com.example.lookingforplayer.controller.application.ApplicationControllerREST;
import com.example.lookingforplayer.controller.authentication.AdminAPIController;
import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.repository.application.ApplicationRepository;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.service.application.ApplicationService;
import com.example.lookingforplayer.service.authentication.AdminServiceImpl;
import com.example.lookingforplayer.service.authentication.CustomUserDetailsService;
import com.example.lookingforplayer.service.notification.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.TestExecutionEvent;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = ApplicationControllerREST.class)
@AutoConfigureMockMvc
public class ApplicationControllerRestTest {
    @Autowired
    private MockMvc mvc;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private ApplicationRepository applicationRepository;

    @MockBean
    private ApplicationService applicationService;

    @MockBean
    private NotificationService notificationService;

    @MockBean
    private CustomUserDetailsService userService;

    private User user1, user2, team1;
    private PlayerApplication app1,app2;
    private CustomUserDetails userDetails1, userDetails2,teamDetails1;

    @BeforeEach // sebelum ngejalanin semua test
    public void setUp() { // buat user dulu
        user1 = new User();
        user1.setId(0L);
        user1.setUsername("audi");
        user1.setPassword("bUDI");
        user1.setRole("PLAYER");

        user2 = new User();
        user2.setId(1L);
        user2.setUsername("bono");
        user2.setPassword("bOnI");
        user2.setRole("PLAYER");

        team1=new User();
        team1.setId(2L);
        team1.setUsername("Beluga");
        team1.setPassword("Ikan_Beluga");
        team1.setRole("TEAM");

        app1=new PlayerApplication();
        app1.setId(0);
        app1.setPostId("UUI1");
        app1.setTeamId(team1.getId());
        app1.setPlayerId(user1.getId());
        app1.setDescription("Aku user 1");

        app2=new PlayerApplication();
        app2.setId(0);
        app2.setPostId("UUI1");
        app2.setTeamId(team1.getId());
        app2.setPlayerId(user2.getId());
        app2.setDescription("Aku user 2");

        userDetails1 = new CustomUserDetails(user1);
        userDetails2 = new CustomUserDetails(user2);
        teamDetails1=new CustomUserDetails(team1);
        when(userRepository.findByUsername("audi")).thenReturn(user1);
        when(userRepository.findByUsername("bono")).thenReturn(user2);
        when(userRepository.findByUsername("Beluga")).thenReturn(team1);
    }

    @Test
    @WithUserDetails(value="Beluga",userDetailsServiceBeanName="userDetailsService",setupBefore= TestExecutionEvent.TEST_EXECUTION)
    public void getAllApplicationTest() throws Exception{
        Iterable<PlayerApplication> applications = Arrays.asList(app1, app2);
        when(applicationService.getListApplication()).thenReturn(applications);
        when(applicationRepository.findAll()).thenReturn((List<PlayerApplication>) applications);
        mvc.perform(get("/application_rest/list")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }
    @Test
    @WithUserDetails(value="Beluga",userDetailsServiceBeanName="userDetailsService",setupBefore= TestExecutionEvent.TEST_EXECUTION)
    public void getApplicationByPostIdTest() throws Exception{
        Iterable<PlayerApplication> applications = Arrays.asList(app1, app2);
        when(applicationService.getApplicationByPostId("UUI1")).thenReturn(applications);
        when(applicationRepository.findByPostIdAndIsModifiedFalse("UUI1")).thenReturn((List<PlayerApplication>) applications);
        mvc.perform(get("/application_rest/list-post-application/UUI1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }
    @Test
    @WithUserDetails(value="Beluga",userDetailsServiceBeanName="userDetailsService",setupBefore= TestExecutionEvent.TEST_EXECUTION)
    public void getApplicationByApplicationIdTest() throws Exception{
        when(applicationService.getApplicationById(0)).thenReturn(Optional.ofNullable(app1));
        when(applicationRepository.findById(0)).thenReturn(Optional.ofNullable(app1));
        mvc.perform(get("/application_rest/list-post-application/0")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }

}
