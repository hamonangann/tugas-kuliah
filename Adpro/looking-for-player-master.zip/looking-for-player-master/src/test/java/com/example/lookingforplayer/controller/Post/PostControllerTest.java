

package com.example.lookingforplayer.controller.Post;
import com.example.lookingforplayer.controller.post.LookingForPlayerPostGetController;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.post.LookingForPlayerPostGet;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import com.example.lookingforplayer.repository.post.LookingForPlayerPostGetRepository;
import com.example.lookingforplayer.service.application.ApplicationService;
import com.example.lookingforplayer.service.post.LookingForPlayerPostGetService;
import com.example.lookingforplayer.service.post.LookingForPlayerPostGetServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.TestExecutionEvent;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import javax.print.attribute.standard.Media;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = LookingForPlayerPostGetController.class)
@AutoConfigureMockMvc
class PostControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private LookingForPlayerPostGetService lookingForPlayerPostGetServiceImpl;

    @MockBean
    private ApplicationService applicationService;

    @MockBean
    private LookingForPlayerPostGetRepository lookingForPlayerPostGetRepository;

    @MockBean
    private UserRepository userRepository;

    private User user1, user2;
    private CustomUserDetails userDetails1, userDetails2;
    private LookingForPlayerPostGet lookingForPlayerPostGet;
    private LookingForPlayerPostGet temp;

    @BeforeEach // sebelum ngejalanin semua test
    public void setUp() { // buat user dulu
        user1 = new User();
        user1.setId(0L);
        user1.setUsername("audi");
        user1.setPassword("bUDI");
        user1.setRole("TEAM");

        user2 = new User();
        user2.setId(1L);
        user2.setUsername("bono");
        user2.setPassword("bOnI");
        user2.setRole("PLAYER");

        temp = new LookingForPlayerPostGet();
        temp.setId("P3");
        temp.setName("Test3");
        temp.setTeamOwner(0L);
        temp.setDesc("Mencari Player 3");

        userDetails1 = new CustomUserDetails(user1);
        userDetails2 = new CustomUserDetails(user2);
        when(userRepository.findByUsername("audi")).thenReturn(user1);
        when(userRepository.findByUsername("bono")).thenReturn(user2);


    }

    @Test
    @WithUserDetails(value = "audi", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    void testPostView() throws Exception{
        lookingForPlayerPostGet = new LookingForPlayerPostGet();
        lookingForPlayerPostGet.setId("P1");
        lookingForPlayerPostGet.setName("Test1");
        lookingForPlayerPostGet.setTeamOwner(1);
        lookingForPlayerPostGet.setDesc("Mencari Player");

        Iterable<LookingForPlayerPostGet> post = Arrays.asList(lookingForPlayerPostGet);
        when(lookingForPlayerPostGetServiceImpl.getListPost()).thenReturn((List<LookingForPlayerPostGet>) post);
        when(lookingForPlayerPostGetRepository.findAll()).thenReturn((List<LookingForPlayerPostGet>) post);
        mvc.perform(get("/post")
                .contentType(MediaType.TEXT_HTML)).andExpect(status().isOk()).andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }
    @Test
    @WithUserDetails(value = "audi", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    void testCreatePost() throws Exception {
        mvc.perform(get("/post/add-post")
                .contentType(MediaType.TEXT_HTML)).andExpect(status().isOk()).andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }
    @Test
    @WithUserDetails(value = "audi", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    void testUpdatePost() throws Exception {
        when(lookingForPlayerPostGetServiceImpl.getById("P3")).thenReturn(temp);
        when(lookingForPlayerPostGetRepository.getById("P3")).thenReturn(temp);
        mvc.perform(get("/post/updatepost/P3")
                .contentType(MediaType.TEXT_HTML)).andExpect(status().isOk()).andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }
    @Test
    @WithUserDetails(value = "bono", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    void testGetPostById() throws Exception {
        when(lookingForPlayerPostGetServiceImpl.getById("P3")).thenReturn(temp);
        when(lookingForPlayerPostGetRepository.getById("P3")).thenReturn(temp);
        mvc.perform(get("/post/getpost/P3")
                .contentType(MediaType.TEXT_HTML)).andExpect(status().isOk()).andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML));
    }
    @Test
    @WithUserDetails(value = "audi", userDetailsServiceBeanName = "userDetailsService", setupBefore = TestExecutionEvent.TEST_EXECUTION)
    void testDeletePost() throws Exception {
        when(lookingForPlayerPostGetServiceImpl.getById("P3")).thenReturn(temp);
        when(lookingForPlayerPostGetRepository.getById("P3")).thenReturn(temp);
        mvc.perform(get("/post/delete-post/P3")).andExpect(status().is3xxRedirection());
    }
}
