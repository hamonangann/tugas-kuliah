package com.example.lookingforplayer.service.authentication;

import com.example.lookingforplayer.model.application.Application;
import com.example.lookingforplayer.model.application.PlayerApplication;
import com.example.lookingforplayer.model.authentication.CustomUserDetails;
import com.example.lookingforplayer.model.authentication.User;
import com.example.lookingforplayer.model.authentication.dto.GetUserDTO;
import com.example.lookingforplayer.repository.application.ApplicationRepository;
import com.example.lookingforplayer.repository.authentication.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class AdminServiceImplTest {
    @InjectMocks
    private AdminServiceImpl adminService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ApplicationRepository applicationRepository;

    private User user1, user2;
    private PlayerApplication app1, app2;

    @BeforeEach // sebelum ngejalanin semua test
    public void setUp() { // buat user dulu
        user1 = new User();
        user1.setId(0L);
        user1.setUsername("audi");
        user1.setPassword("bUDI");
        user1.setRole("ADMIN");

        user2 = new User();
        user2.setId(1L);
        user2.setUsername("bono");
        user2.setPassword("bOnI");
        user2.setRole("PLAYER");

        PlayerApplication app1 = new PlayerApplication();
        app1.setId(0);

        PlayerApplication app2 = new PlayerApplication();
        app2.setId(1);
    }

    @Test
    public void testGetListUsers() {
        Iterable<User> users = Arrays.asList(user1, user2);
        when(userRepository.findAll()).thenReturn((List<User>) users);
        Iterable<User> loaded = adminService.getListUser();
        assertIterableEquals(loaded, users);
    }

    @Test
    public void testGetListUserDTO() {
        Iterable<User> users = Arrays.asList(user1, user2);
        when(userRepository.findAll()).thenReturn((List<User>) users);
        Iterable<GetUserDTO> loaded = adminService.getListUserDTO();
        Iterator<GetUserDTO> it = loaded.iterator();
        Iterator<User> it2 = users.iterator();
        while (it.hasNext()) {
            GetUserDTO dto = it.next();
            User actual = it2.next();
            assertEquals(dto.getId(), actual.getId());
            assertEquals(dto.getRole(), actual.getRole());
            assertEquals(dto.getId(), actual.getId());
        }

    }

    @Test
    public void testGetListApplications() {
        Iterable<PlayerApplication> applications = Arrays.asList(app1, app2);
        when(applicationRepository.findAll()).thenReturn((List<PlayerApplication>) applications);
        Iterable<PlayerApplication> loaded = adminService.getListApplication();
        assertIterableEquals(loaded, applications);
    }

}
