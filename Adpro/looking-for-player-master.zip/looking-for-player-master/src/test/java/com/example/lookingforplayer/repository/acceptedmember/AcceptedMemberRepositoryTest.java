package com.example.lookingforplayer.repository.acceptedmember;

import com.example.lookingforplayer.model.acceptedmember.AcceptedMember;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(value = false)
class AcceptedMemberRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private AcceptedMemberRepository acceptedMemberRepository;

    @Test
    void whenSaveShouldReturnSavedAcceptedMember() {
        // Given an accepted member object
        AcceptedMember acceptedMember = AcceptedMember.builder()
                .playerId(1L)
                .teamId(2L)
                .joinedDate(new Date())
                .build();

        // When save to repository
        AcceptedMember savedAcceptedMember = acceptedMemberRepository.save(acceptedMember);

        // Then return the saved object
        AcceptedMember existAcceptedMember = entityManager.find(AcceptedMember.class, savedAcceptedMember.getMemberId());
        assertThat(acceptedMember.getMemberId()).isEqualTo(existAcceptedMember.getMemberId());

        // Delete the object to reset
        acceptedMemberRepository.deleteById(acceptedMember.getMemberId());

    }

    @Test
    void whenFindAllShouldReturnAcceptedMemberList() {
        // Given 2 accepted member objects
        AcceptedMember acceptedMember1 = AcceptedMember.builder()
                .teamId(1L)
                .playerId(2L)
                .joinedDate(new Date())
                .build();

        AcceptedMember acceptedMember2 = AcceptedMember.builder()
                .teamId(1L)
                .playerId(3L)
                .joinedDate(new Date())
                .build();

        acceptedMemberRepository.save(acceptedMember1);
        acceptedMemberRepository.save(acceptedMember2);

        // When find all in repository
        List<AcceptedMember> acceptedMemberList = acceptedMemberRepository.findAll();

        // Then return all accepted member objects
        assertThat(acceptedMemberList).isNotNull();
        assertThat(acceptedMemberList.size()).isEqualTo(2);

        // Delete the object to reset
        acceptedMemberRepository.deleteById(acceptedMember1.getMemberId());
        acceptedMemberRepository.deleteById(acceptedMember2.getMemberId());
    }
}